export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDateLabel(dateString: string): string {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });
}

export function formatShortDate(dateString: string): string {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function getShortDayName(dateString: string): string {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', { weekday: 'narrow' }); // M, T, W, etc.
}

export function getDayInitial(dateString: string): string {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', { weekday: 'short' }); // Mon, Tue, etc.
}

export function getDayNumber(dateString: string): number {
  const [, , day] = dateString.split('-').map(Number);
  return day;
}

export function addDays(dateString: string, days: number): string {
  const [year, month, day] = dateString.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  date.setDate(date.getDate() + days);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Returns an array of date strings for the last N days up to referenceDate (inclusive).
 */
export function getRecentDateStrings(count: number = 7, referenceDate: string = getTodayDateString()): string[] {
  const dates: string[] = [];
  for (let i = count - 1; i >= 0; i--) {
    dates.push(addDays(referenceDate, -i));
  }
  return dates;
}

/**
 * Returns an array of the current week's dates (starting Monday or 6 days before today)
 */
export function getWeekDays(referenceDate: string = getTodayDateString()): string[] {
  const [year, month, day] = referenceDate.split('-').map(Number);
  const curr = new Date(year, month - 1, day);
  // Get Monday of current week
  const dayOfWeek = curr.getDay(); // 0 is Sunday, 1 is Monday
  const distanceToMonday = (dayOfWeek + 6) % 7; // days since Monday
  
  const monday = new Date(curr);
  monday.setDate(curr.getDate() - distanceToMonday);

  const week: string[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const dayStr = String(d.getDate()).padStart(2, '0');
    week.push(`${y}-${m}-${dayStr}`);
  }
  return week;
}

/**
 * Computes current streak and best streak accurately from history.
 */
export function calculateStreaks(
  history: Record<string, boolean> = {},
  todayDate: string = getTodayDateString()
): { currentStreak: number; bestStreak: number; totalCount: number } {
  const datesWithCheckins = Object.keys(history).filter((d) => history[d]);
  const totalCount = datesWithCheckins.length;

  if (totalCount === 0) {
    return { currentStreak: 0, bestStreak: 0, totalCount: 0 };
  }

  // Calculate current streak
  let currentStreak = 0;
  let checkDate = todayDate;

  // If today is checked in, count today and walk backward
  if (history[todayDate]) {
    currentStreak = 1;
    checkDate = addDays(todayDate, -1);
    while (history[checkDate]) {
      currentStreak++;
      checkDate = addDays(checkDate, -1);
    }
  } else {
    // If today is NOT checked in yet, check if yesterday was checked in
    const yesterday = addDays(todayDate, -1);
    if (history[yesterday]) {
      currentStreak = 1;
      checkDate = addDays(yesterday, -1);
      while (history[checkDate]) {
        currentStreak++;
        checkDate = addDays(checkDate, -1);
      }
    } else {
      currentStreak = 0;
    }
  }

  // Calculate best all-time streak by sorting sorted unique dates
  const sortedDates = [...new Set(datesWithCheckins)].sort();
  let bestStreak = 0;
  let runningStreak = 0;
  let prevDate: string | null = null;

  for (const d of sortedDates) {
    if (!prevDate) {
      runningStreak = 1;
    } else {
      const expectedNext = addDays(prevDate, 1);
      if (d === expectedNext) {
        runningStreak++;
      } else {
        runningStreak = 1;
      }
    }
    prevDate = d;
    if (runningStreak > bestStreak) {
      bestStreak = runningStreak;
    }
  }

  return {
    currentStreak,
    bestStreak: Math.max(bestStreak, currentStreak),
    totalCount,
  };
}
