import { Habit, HabitTemplate, TodoItem } from '../types';
import { addDays, getTodayDateString } from './dateUtils';

export const HABIT_TEMPLATES: HabitTemplate[] = [
  {
    name: 'Drinking Water',
    category: 'health',
    icon: 'Droplets',
    color: '#0284c7', // sky-600
    description: 'Track daily hydration (2-3L water goal)',
  },
  {
    name: 'Swimming',
    category: 'fitness',
    icon: 'Waves',
    color: '#06b6d4', // cyan-500
    description: 'Pool laps, technique & stamina training',
  },
  {
    name: 'Workouts',
    category: 'fitness',
    icon: 'Dumbbell',
    color: '#10b981', // emerald-500
    description: 'Strength training, gym or home calisthenics',
  },
  {
    name: 'Skincare',
    category: 'health',
    icon: 'Sparkles',
    color: '#f43f5e', // rose-500
    description: 'Morning or night skin wellness routine',
  },
  {
    name: 'Study Time',
    category: 'education',
    icon: 'BookOpen',
    color: '#f59e0b', // amber-500
    description: 'Focused academic learning or coding session',
  },
  {
    name: 'Going College',
    category: 'attendance',
    icon: 'GraduationCap',
    color: '#8b5cf6', // violet-500
    description: 'Class lectures & daily campus attendance',
  },
];

const HABITS_STORAGE_KEY = 'habit_tracker_habits_v2';
const TODOS_STORAGE_KEY = 'habit_tracker_todos_v2';
const SETTINGS_STORAGE_KEY = 'habit_tracker_settings_v2';

export interface AppSettings {
  soundEnabled: boolean;
  hapticEnabled: boolean;
}

export function getDefaultHabits(): Habit[] {
  const today = getTodayDateString();
  const yesterday = addDays(today, -1);
  const twoDaysAgo = addDays(today, -2);
  const threeDaysAgo = addDays(today, -3);

  return [
    {
      id: 'habit-water',
      name: 'Drinking Water',
      category: 'health',
      icon: 'Droplets',
      color: '#0284c7',
      createdAt: threeDaysAgo,
      history: {
        [threeDaysAgo]: true,
        [twoDaysAgo]: true,
        [yesterday]: true,
        [today]: true,
      },
      streak: 4,
      bestStreak: 4,
      notes: 'Aim for 2.5 Liters throughout the day',
      targetDaysPerWeek: 7,
    },
    {
      id: 'habit-college',
      name: 'Going College',
      category: 'attendance',
      icon: 'GraduationCap',
      color: '#8b5cf6',
      createdAt: threeDaysAgo,
      history: {
        [threeDaysAgo]: true,
        [twoDaysAgo]: true,
        [yesterday]: true,
      },
      streak: 3,
      bestStreak: 5,
      notes: 'Morning lectures & laboratory attendance',
      targetDaysPerWeek: 5,
    },
    {
      id: 'habit-workout',
      name: 'Workouts',
      category: 'fitness',
      icon: 'Dumbbell',
      color: '#10b981',
      createdAt: threeDaysAgo,
      history: {
        [twoDaysAgo]: true,
        [yesterday]: true,
      },
      streak: 2,
      bestStreak: 7,
      notes: '45 mins resistance or cardio',
      targetDaysPerWeek: 5,
    },
    {
      id: 'habit-skincare',
      name: 'Skincare',
      category: 'health',
      icon: 'Sparkles',
      color: '#f43f5e',
      createdAt: threeDaysAgo,
      history: {
        [yesterday]: true,
        [today]: true,
      },
      streak: 2,
      bestStreak: 6,
      notes: 'Cleanser, moisturizer & SPF protection',
      targetDaysPerWeek: 7,
    },
    {
      id: 'habit-study',
      name: 'Study Time',
      category: 'education',
      icon: 'BookOpen',
      color: '#f59e0b',
      createdAt: threeDaysAgo,
      history: {
        [twoDaysAgo]: true,
        [yesterday]: true,
      },
      streak: 2,
      bestStreak: 4,
      notes: 'Deep work & notes review',
      targetDaysPerWeek: 6,
    },
    {
      id: 'habit-swimming',
      name: 'Swimming',
      category: 'fitness',
      icon: 'Waves',
      color: '#06b6d4',
      createdAt: threeDaysAgo,
      history: {
        [threeDaysAgo]: true,
        [yesterday]: true,
      },
      streak: 1,
      bestStreak: 3,
      notes: 'Pool session / 20 laps',
      targetDaysPerWeek: 3,
    },
  ];
}

export function getDefaultTodos(): TodoItem[] {
  const today = getTodayDateString();
  return [
    {
      id: 'todo-1',
      title: 'Submit college assignment report',
      completed: false,
      dueDate: today,
      createdAt: today,
      priority: 'high',
      category: 'College',
    },
    {
      id: 'todo-2',
      title: 'Refill gym water bottle & pack swim gear',
      completed: true,
      dueDate: today,
      createdAt: today,
      completedAt: today,
      priority: 'medium',
      category: 'Fitness',
    },
    {
      id: 'todo-3',
      title: 'Review Chapter 4 notes for 30 minutes',
      completed: false,
      dueDate: today,
      createdAt: today,
      priority: 'medium',
      category: 'Study',
    },
  ];
}

export function loadHabits(): Habit[] {
  try {
    const raw = localStorage.getItem(HABITS_STORAGE_KEY);
    if (!raw) {
      const defaults = getDefaultHabits();
      saveHabits(defaults);
      return defaults;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return getDefaultHabits();
  } catch (e) {
    console.error('Failed to load habits from localStorage', e);
    return getDefaultHabits();
  }
}

export function saveHabits(habits: Habit[]): void {
  try {
    localStorage.setItem(HABITS_STORAGE_KEY, JSON.stringify(habits));
  } catch (e) {
    console.error('Failed to save habits to localStorage', e);
  }
}

export function loadTodos(): TodoItem[] {
  try {
    const raw = localStorage.getItem(TODOS_STORAGE_KEY);
    if (!raw) {
      const defaults = getDefaultTodos();
      saveTodos(defaults);
      return defaults;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return getDefaultTodos();
  } catch (e) {
    console.error('Failed to load todos from localStorage', e);
    return getDefaultTodos();
  }
}

export function saveTodos(todos: TodoItem[]): void {
  try {
    localStorage.setItem(TODOS_STORAGE_KEY, JSON.stringify(todos));
  } catch (e) {
    console.error('Failed to save todos to localStorage', e);
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) {
      return { soundEnabled: true, hapticEnabled: true };
    }
    return JSON.parse(raw);
  } catch {
    return { soundEnabled: true, hapticEnabled: true };
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}
