export type HabitCategory = 'health' | 'fitness' | 'education' | 'routine' | 'attendance' | 'other';

export interface Habit {
  id: string;
  name: string;
  category: HabitCategory;
  icon: string; // lucide icon name
  color: string; // hex or tailwind class theme
  createdAt: string; // YYYY-MM-DD
  history: Record<string, boolean>; // 'YYYY-MM-DD': true
  streak: number;
  bestStreak: number;
  notes?: string;
  targetDaysPerWeek?: number; // default 7
}

export type TodoPriority = 'low' | 'medium' | 'high';

export interface TodoItem {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string; // YYYY-MM-DD
  createdAt: string;
  completedAt?: string;
  priority: TodoPriority;
  category?: string;
}

export type ActiveTab = 'habits' | 'todos' | 'stats';

export interface HabitTemplate {
  name: string;
  category: HabitCategory;
  icon: string;
  color: string;
  description: string;
}
