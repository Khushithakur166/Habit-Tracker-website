import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Check, Trash2, CheckCircle2, ChevronDown, ChevronRight, Calendar, Flag } from 'lucide-react';
import { TodoItem, TodoPriority } from '../types';
import { getTodayDateString } from '../utils/dateUtils';

interface TodoListProps {
  todos: TodoItem[];
  selectedDate: string;
  onToggleTodo: (id: string) => void;
  onAddTodo: (todo: Omit<TodoItem, 'id' | 'createdAt'>) => void;
  onDeleteTodo: (id: string) => void;
  onClearCompleted: () => void;
}

export const TodoList: React.FC<TodoListProps> = ({
  todos,
  selectedDate,
  onToggleTodo,
  onAddTodo,
  onDeleteTodo,
  onClearCompleted,
}) => {
  const [taskText, setTaskText] = useState('');
  const [priority, setPriority] = useState<TodoPriority>('medium');
  const [category, setCategory] = useState<string>('General');
  const [showCompleted, setShowCompleted] = useState(true);

  const pendingTodos = todos.filter((t) => !t.completed);
  const completedTodos = todos.filter((t) => t.completed);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = taskText.trim();
    if (!trimmed) return;

    onAddTodo({
      title: trimmed,
      completed: false,
      dueDate: selectedDate,
      priority,
      category,
    });

    setTaskText('');
  };

  const priorityStyles: Record<TodoPriority, { label: string; color: string; badge: string }> = {
    high: {
      label: 'High',
      color: 'text-rose-600 dark:text-rose-400',
      badge: 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300',
    },
    medium: {
      label: 'Medium',
      color: 'text-amber-600 dark:text-amber-400',
      badge: 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300',
    },
    low: {
      label: 'Low',
      color: 'text-zinc-500 dark:text-zinc-400',
      badge: 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400',
    },
  };

  return (
    <div className="space-y-4">
      {/* Quick Add Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xs rounded-2xl p-3.5 border border-emerald-100/70 dark:border-zinc-800 shadow-xs transition-all hover:border-emerald-200"
      >
        <div className="flex items-center gap-2">
          <input
            type="text"
            id="new-todo-input"
            value={taskText}
            onChange={(e) => setTaskText(e.target.value)}
            placeholder="Add a one-time task for today..."
            className="flex-1 bg-emerald-50/40 dark:bg-zinc-800/60 rounded-xl px-2.5 py-1.5 text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-emerald-400/40 border border-emerald-100/50 dark:border-zinc-700/60 transition-all"
          />
          <button
            type="submit"
            disabled={!taskText.trim()}
            id="add-todo-btn"
            className="h-9 px-3.5 rounded-xl bg-zinc-900 hover:bg-emerald-600 dark:bg-zinc-100 dark:hover:bg-emerald-400 dark:hover:text-zinc-900 text-white dark:text-zinc-900 font-semibold text-xs flex items-center gap-1.5 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-xs cursor-pointer active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </div>

        {/* Priority & Tags Pill Row */}
        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800/80 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-medium text-zinc-400 dark:text-zinc-500">
              Priority:
            </span>
            {(['low', 'medium', 'high'] as TodoPriority[]).map((p) => (
              <button
                type="button"
                key={p}
                onClick={() => setPriority(p)}
                className={`px-2 py-0.5 rounded-md text-[10px] font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                  priority === p
                    ? priorityStyles[p].badge
                    : 'text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1">
            {['College', 'Errand', 'Study', 'Personal'].map((cat) => (
              <button
                type="button"
                key={cat}
                onClick={() => setCategory(cat)}
                className={`text-[10px] px-1.5 py-0.5 rounded-sm transition-colors cursor-pointer ${
                  category === cat
                    ? 'bg-zinc-200 dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300'
                }`}
              >
                #{cat}
              </button>
            ))}
          </div>
        </div>
      </form>

      {/* Progress Counter */}
      <div className="flex items-center justify-between px-1 text-xs">
        <span className="font-semibold text-zinc-700 dark:text-zinc-300">
          {pendingTodos.length} pending · {completedTodos.length} completed
        </span>
        {completedTodos.length > 0 && (
          <button
            onClick={onClearCompleted}
            id="clear-completed-todos-btn"
            className="text-zinc-400 hover:text-rose-500 dark:hover:text-rose-400 font-medium transition-colors cursor-pointer"
          >
            Clear completed
          </button>
        )}
      </div>

      {/* Pending Tasks */}
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {pendingTodos.length === 0 && completedTodos.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-12 px-4 text-center bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/60 dark:border-zinc-800"
            >
              <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                No to-dos yet
              </p>
              <p className="text-xs text-zinc-400 dark:text-zinc-500 mt-1 max-w-[240px] mx-auto">
                Add quick one-time tasks for college, assignments, groceries, or reminders.
              </p>
            </motion.div>
          ) : (
            pendingTodos.map((todo) => {
              const pStyle = priorityStyles[todo.priority] || priorityStyles.medium;
              return (
                <motion.div
                  key={todo.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  whileHover={{ y: -1 }}
                  id={`todo-item-${todo.id}`}
                  className="group bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xs rounded-2xl p-3.5 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between gap-3 shadow-xs hover:border-emerald-300/70 dark:hover:border-zinc-700 transition-all hover:shadow-xs"
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <button
                      type="button"
                      id={`toggle-todo-${todo.id}`}
                      onClick={() => onToggleTodo(todo.id)}
                      className="w-6 h-6 rounded-lg border-2 border-zinc-300 dark:border-zinc-600 flex items-center justify-center hover:border-emerald-500 dark:hover:border-emerald-500 transition-colors cursor-pointer shrink-0"
                    >
                      {/* empty checkbox */}
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-zinc-900 dark:text-zinc-100 font-medium truncate">
                        {todo.title}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-sm ${pStyle.badge}`}>
                          {pStyle.label}
                        </span>
                        {todo.category && (
                          <span className="text-[10px] text-zinc-400 font-medium">
                            #{todo.category}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onDeleteTodo(todo.id)}
                    aria-label="Delete task"
                    className="opacity-0 group-hover:opacity-100 p-1.5 text-zinc-400 hover:text-rose-500 rounded-lg transition-all cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      {/* Completed Tasks Accordion */}
      {completedTodos.length > 0 && (
        <div className="pt-2">
          <button
            type="button"
            onClick={() => setShowCompleted(!showCompleted)}
            className="flex items-center gap-1.5 text-xs font-semibold text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 mb-2 cursor-pointer"
          >
            {showCompleted ? (
              <ChevronDown className="w-3.5 h-3.5" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5" />
            )}
            <span>Completed ({completedTodos.length})</span>
          </button>

          {showCompleted && (
            <div className="space-y-2">
              <AnimatePresence mode="popLayout">
                {completedTodos.map((todo) => (
                  <motion.div
                    key={todo.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    id={`todo-completed-${todo.id}`}
                    className="group bg-zinc-50/70 dark:bg-zinc-900/40 rounded-2xl p-3 border border-zinc-200/50 dark:border-zinc-800/50 flex items-center justify-between gap-3 opacity-75 hover:opacity-100 transition-opacity"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <button
                        type="button"
                        onClick={() => onToggleTodo(todo.id)}
                        className="w-6 h-6 rounded-lg bg-emerald-500 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                      </button>
                      <p className="text-sm text-zinc-500 dark:text-zinc-400 line-through truncate flex-1">
                        {todo.title}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteTodo(todo.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 text-zinc-400 hover:text-rose-500 rounded-lg transition-all cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
