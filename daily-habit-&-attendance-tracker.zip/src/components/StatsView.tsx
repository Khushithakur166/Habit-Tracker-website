import React from 'react';
import { motion } from 'motion/react';
import { Flame, Award, Calendar, CheckCircle2, TrendingUp, GraduationCap, RotateCcw } from 'lucide-react';
import { Habit } from '../types';
import { HabitIcon } from './HabitIcon';
import { getRecentDateStrings, getTodayDateString } from '../utils/dateUtils';

interface StatsViewProps {
  habits: Habit[];
  onResetToDefaults: () => void;
  onOpenHabitDetail: (habit: Habit) => void;
}

export const StatsView: React.FC<StatsViewProps> = ({
  habits,
  onResetToDefaults,
  onOpenHabitDetail,
}) => {
  const today = getTodayDateString();
  const past30Days = getRecentDateStrings(30, today);

  // Calculate overall metrics
  const totalAllTimeCheckins = habits.reduce((acc, h) => {
    return acc + Object.keys(h.history).filter((k) => h.history[k]).length;
  }, 0);

  const highestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 0);
  const bestAllTimeStreak = habits.reduce((max, h) => Math.max(max, h.bestStreak), 0);

  // College / Attendance specific habit
  const collegeHabit = habits.find((h) => h.name.toLowerCase().includes('college') || h.category === 'attendance');
  let collegeAttendanceRate = 0;
  let collegeDaysAttended = 0;
  if (collegeHabit) {
    collegeDaysAttended = past30Days.filter((d) => collegeHabit.history[d]).length;
    collegeAttendanceRate = Math.round((collegeDaysAttended / 30) * 100);
  }

  // Calculate today's completion rate
  const completedToday = habits.filter((h) => h.history[today]).length;
  const todayPercentage = habits.length > 0 ? Math.round((completedToday / habits.length) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Today's Overview Ring Card */}
      <div className="bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xs rounded-3xl p-5 border border-emerald-100/70 dark:border-zinc-800 shadow-xs">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
              Today's Attendance
            </span>
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-zinc-100 mt-1">
              {todayPercentage}% Complete
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              {completedToday} of {habits.length} activities completed today
            </p>
          </div>

          <div className="w-16 h-16 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 border-4 border-emerald-500 flex items-center justify-center font-bold text-emerald-700 dark:text-emerald-400 text-lg shadow-xs">
            {todayPercentage}%
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-2.5 rounded-full overflow-hidden mt-4">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${todayPercentage}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 h-full rounded-full"
          />
        </div>
      </div>

      {/* College & Attendance Tracker Card if available */}
      {collegeHabit && (
        <div className="bg-gradient-to-br from-violet-50 to-indigo-50 dark:from-violet-950/40 dark:to-indigo-950/30 rounded-3xl p-5 border border-violet-200/60 dark:border-violet-900/60 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-violet-600 text-white flex items-center justify-center shadow-xs">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                  {collegeHabit.name} Attendance
                </h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Campus & lecture attendance status
                </p>
              </div>
            </div>
            <button
              onClick={() => onOpenHabitDetail(collegeHabit)}
              className="text-xs font-semibold text-violet-700 dark:text-violet-300 hover:underline"
            >
              View Grid
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-2">
            <div className="p-2.5 bg-white/80 dark:bg-zinc-900/70 rounded-xl border border-violet-100 dark:border-violet-900/40 text-center">
              <div className="text-lg font-bold text-violet-700 dark:text-violet-300">
                {collegeDaysAttended}d
              </div>
              <div className="text-[10px] text-zinc-500 font-medium">Attended (30d)</div>
            </div>

            <div className="p-2.5 bg-white/80 dark:bg-zinc-900/70 rounded-xl border border-violet-100 dark:border-violet-900/40 text-center">
              <div className="text-lg font-bold text-violet-700 dark:text-violet-300">
                {collegeAttendanceRate}%
              </div>
              <div className="text-[10px] text-zinc-500 font-medium">Rate</div>
            </div>

            <div className="p-2.5 bg-white/80 dark:bg-zinc-900/70 rounded-xl border border-violet-100 dark:border-violet-900/40 text-center">
              <div className="text-lg font-bold text-violet-700 dark:text-violet-300">
                {collegeHabit.streak}d
              </div>
              <div className="text-[10px] text-zinc-500 font-medium">Streak</div>
            </div>
          </div>
        </div>
      )}

      {/* Global Metrics Row */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-500 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5 fill-amber-500" />
          </div>
          <div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
              Top Active Streak
            </div>
            <div className="text-lg font-bold text-zinc-900 dark:text-zinc-100">
              {highestStreak} {highestStreak === 1 ? 'day' : 'days'}
            </div>
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200/80 dark:border-zinc-800 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
              Best All-Time
            </div>
            <div className="text-lg font-bold text-zinc-900 dark:text-zinc-100">
              {bestAllTimeStreak} days
            </div>
          </div>
        </div>
      </div>

      {/* Habit Streak Breakdown List */}
      <div className="bg-white dark:bg-zinc-900 rounded-3xl p-5 border border-zinc-200/80 dark:border-zinc-800 shadow-xs">
        <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100 mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-500" />
          <span>Active Habits Streak Leaderboard</span>
        </h4>

        <div className="divide-y divide-zinc-100 dark:divide-zinc-800">
          {habits
            .slice()
            .sort((a, b) => b.streak - a.streak)
            .map((h, idx) => (
              <button
                key={h.id}
                onClick={() => onOpenHabitDetail(h)}
                className="w-full py-3 flex items-center justify-between text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/40 rounded-xl px-2 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-zinc-400 w-4">
                    #{idx + 1}
                  </span>
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${h.color}20`, color: h.color }}
                  >
                    <HabitIcon name={h.icon} className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                      {h.name}
                    </div>
                    <div className="text-[11px] text-zinc-400">
                      All-time: {Object.keys(h.history).filter((k) => h.history[k]).length} check-ins
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 font-bold text-xs text-amber-600 dark:text-amber-400">
                  <Flame className="w-3.5 h-3.5 fill-amber-500" />
                  <span>{h.streak}d</span>
                </div>
              </button>
            ))}
        </div>
      </div>

      {/* Persistence and Reset Controls */}
      <div className="pt-2 text-center">
        <p className="text-xs text-zinc-400 dark:text-zinc-500 mb-2">
          All daily check-ins, attendance logs, and to-dos are saved locally on your device.
        </p>
        <button
          type="button"
          onClick={() => {
            if (window.confirm('Reset habits and to-dos to initial defaults?')) {
              onResetToDefaults();
            }
          }}
          className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition-colors py-1 px-3 rounded-lg border border-zinc-200 dark:border-zinc-800 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Default Activities</span>
        </button>
      </div>
    </div>
  );
};
