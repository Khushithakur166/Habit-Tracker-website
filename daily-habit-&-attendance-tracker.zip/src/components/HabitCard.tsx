import React from 'react';
import { motion } from 'motion/react';
import { Check, Flame, ChevronRight, Info } from 'lucide-react';
import { Habit } from '../types';
import { HabitIcon } from './HabitIcon';
import { getDayInitial, getRecentDateStrings, getTodayDateString } from '../utils/dateUtils';

interface HabitCardProps {
  habit: Habit;
  selectedDate: string;
  onToggleCheckin: (habitId: string, date: string) => void;
  onOpenDetail: (habit: Habit) => void;
}

export const HabitCard: React.FC<HabitCardProps> = ({
  habit,
  selectedDate,
  onToggleCheckin,
  onOpenDetail,
}) => {
  const isDoneOnDate = !!habit.history[selectedDate];
  const isToday = selectedDate === getTodayDateString();
  const recent7Days = getRecentDateStrings(7, selectedDate);

  // Category labels and styles
  const categoryLabels: Record<string, string> = {
    attendance: 'Campus / Class',
    health: 'Health',
    fitness: 'Fitness',
    education: 'Study',
    routine: 'Routine',
    other: 'Habit',
  };

  const handleCheckinClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleCheckin(habit.id, selectedDate);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.2 }}
      id={`habit-card-${habit.id}`}
      onClick={() => onOpenDetail(habit)}
      className={`group relative rounded-2xl p-4 transition-all duration-200 cursor-pointer border ${
        isDoneOnDate
          ? 'bg-gradient-to-r from-emerald-50/80 via-white to-emerald-50/40 dark:from-emerald-950/20 dark:via-zinc-900/90 dark:to-zinc-900 border-emerald-500/35 shadow-xs'
          : 'bg-white/90 dark:bg-zinc-900/90 border-zinc-200/80 dark:border-zinc-800 shadow-xs hover:border-emerald-300/70 dark:hover:border-zinc-700 hover:shadow-md'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        {/* Left: Icon & Info */}
        <div className="flex items-start gap-3.5 flex-1 min-w-0">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-xs transition-transform group-hover:scale-105"
            style={{
              backgroundColor: `${habit.color}18`,
              color: habit.color,
            }}
          >
            <HabitIcon name={habit.icon} className="w-6 h-6" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-base text-zinc-900 dark:text-zinc-100 truncate">
                {habit.name}
              </h3>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400 shrink-0">
                {categoryLabels[habit.category] || habit.category}
              </span>
            </div>

            {habit.notes && (
              <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate mt-0.5">
                {habit.notes}
              </p>
            )}

            {/* Streak & Attendance count badge */}
            <div className="flex items-center gap-3 mt-2 text-xs">
              <div className="flex items-center gap-1 font-medium text-amber-600 dark:text-amber-400">
                <Flame className={`w-3.5 h-3.5 ${habit.streak > 0 ? 'fill-amber-500 animate-pulse' : 'text-zinc-400'}`} />
                <span>
                  {habit.streak} {habit.streak === 1 ? 'day' : 'days'} streak
                </span>
              </div>
              <span className="text-zinc-300 dark:text-zinc-700">•</span>
              <span className="text-zinc-400 dark:text-zinc-500 text-[11px]">
                Best: {habit.bestStreak}d
              </span>
            </div>
          </div>
        </div>

        {/* Right: Tactile Check-In Button */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.9 }}
          id={`checkin-btn-${habit.id}`}
          onClick={handleCheckinClick}
          aria-label={isDoneOnDate ? `Mark ${habit.name} incomplete` : `Mark ${habit.name} complete`}
          className={`shrink-0 w-11 h-11 rounded-xl flex items-center justify-center transition-all shadow-xs cursor-pointer ${
            isDoneOnDate
              ? 'bg-emerald-500 text-white shadow-emerald-500/25 ring-2 ring-emerald-500/30'
              : 'bg-zinc-100 dark:bg-zinc-800/80 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-700'
          }`}
        >
          {isDoneOnDate ? (
            <motion.div
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 20 }}
            >
              <Check className="w-6 h-6 stroke-[2.5]" />
            </motion.div>
          ) : (
            <div className="w-5 h-5 rounded-full border-2 border-dashed border-zinc-400 dark:border-zinc-500" />
          )}
        </motion.button>
      </div>

      {/* Mini 7-day attendance streak row */}
      <div className="mt-3.5 pt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-medium text-zinc-400 dark:text-zinc-500 mr-1">
            Last 7d:
          </span>
          {recent7Days.map((d) => {
            const attended = !!habit.history[d];
            const isDaySelected = d === selectedDate;
            const letter = getDayInitial(d).slice(0, 1);
            return (
              <div
                key={d}
                title={`${d}: ${attended ? 'Done' : 'Missed'}`}
                className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-medium transition-colors ${
                  attended
                    ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-bold'
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-600'
                } ${isDaySelected ? 'ring-1.5 ring-zinc-900 dark:ring-zinc-100' : ''}`}
              >
                {letter}
              </div>
            );
          })}
        </div>

        <div className="flex items-center text-[11px] font-medium text-zinc-400 group-hover:text-zinc-600 dark:group-hover:text-zinc-300 transition-colors">
          <span>Details</span>
          <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
        </div>
      </div>
    </motion.div>
  );
};
