import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Sparkles, Check, ChevronDown } from 'lucide-react';
import { Habit, HabitCategory, HabitTemplate } from '../types';
import { HABIT_TEMPLATES } from '../utils/storage';
import { AVAILABLE_ICONS, HabitIcon } from './HabitIcon';
import { getTodayDateString } from '../utils/dateUtils';

interface AddHabitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'history' | 'streak' | 'bestStreak'>) => void;
  existingHabitNames: string[];
}

const PRESET_COLORS = [
  '#0284c7', // Sky
  '#06b6d4', // Cyan
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#f43f5e', // Rose
  '#8b5cf6', // Violet
  '#6366f1', // Indigo
  '#ec4899', // Pink
  '#14b8a6', // Teal
];

const CATEGORIES: { id: HabitCategory; label: string }[] = [
  { id: 'attendance', label: 'Attendance / Campus' },
  { id: 'health', label: 'Health & Wellness' },
  { id: 'fitness', label: 'Fitness & Sports' },
  { id: 'education', label: 'Study & Learning' },
  { id: 'routine', label: 'Daily Routine' },
  { id: 'other', label: 'Other' },
];

export const AddHabitModal: React.FC<AddHabitModalProps> = ({
  isOpen,
  onClose,
  onAddHabit,
  existingHabitNames,
}) => {
  const [tab, setTab] = useState<'presets' | 'custom'>('presets');
  const [name, setName] = useState('');
  const [category, setCategory] = useState<HabitCategory>('routine');
  const [icon, setIcon] = useState('Flame');
  const [color, setColor] = useState('#10b981');
  const [notes, setNotes] = useState('');
  const [targetDaysPerWeek, setTargetDaysPerWeek] = useState(7);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSelectTemplate = (template: HabitTemplate) => {
    onAddHabit({
      name: template.name,
      category: template.category,
      icon: template.icon,
      color: template.color,
      notes: template.description,
      targetDaysPerWeek: template.category === 'attendance' ? 5 : 7,
    });
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Please provide an activity name');
      return;
    }
    if (existingHabitNames.some((n) => n.toLowerCase() === trimmed.toLowerCase())) {
      setError('A habit with this name already exists');
      return;
    }

    onAddHabit({
      name: trimmed,
      category,
      icon,
      color,
      notes: notes.trim() || undefined,
      targetDaysPerWeek,
    });
    // Reset form
    setName('');
    setNotes('');
    setError('');
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-t-3xl sm:rounded-3xl shadow-xl border border-zinc-200 dark:border-zinc-800 max-h-[90vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-5 pt-5 pb-3 flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800">
            <div>
              <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-100">
                Add Habit / Activity
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Track repeatable routines, workouts & attendance
              </p>
            </div>
            <button
              onClick={onClose}
              id="close-add-habit-modal"
              className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Toggle Presets vs Custom */}
          <div className="px-5 pt-3">
            <div className="grid grid-cols-2 p-1 bg-zinc-100 dark:bg-zinc-800/80 rounded-xl text-xs font-semibold">
              <button
                type="button"
                id="preset-habits-tab"
                onClick={() => setTab('presets')}
                className={`py-2 rounded-lg transition-all ${
                  tab === 'presets'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400'
                }`}
              >
                Suggested Templates
              </button>
              <button
                type="button"
                id="custom-habit-tab"
                onClick={() => setTab('custom')}
                className={`py-2 rounded-lg transition-all ${
                  tab === 'custom'
                    ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                    : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400'
                }`}
              >
                Custom Habit
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="p-5 overflow-y-auto space-y-4">
            {tab === 'presets' ? (
              <div className="space-y-2.5">
                <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                  Tap to add any popular daily habit or attendance tracker:
                </p>
                <div className="grid grid-cols-1 gap-2.5">
                  {HABIT_TEMPLATES.map((tmpl) => {
                    const isAlreadyAdded = existingHabitNames.some(
                      (n) => n.toLowerCase() === tmpl.name.toLowerCase()
                    );
                    return (
                      <button
                        key={tmpl.name}
                        disabled={isAlreadyAdded}
                        onClick={() => handleSelectTemplate(tmpl)}
                        className={`flex items-center justify-between p-3 rounded-2xl border text-left transition-all ${
                          isAlreadyAdded
                            ? 'opacity-40 bg-zinc-50 dark:bg-zinc-800/40 border-dashed border-zinc-200 dark:border-zinc-800 cursor-not-allowed'
                            : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 cursor-pointer shadow-xs'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                            style={{
                              backgroundColor: `${tmpl.color}20`,
                              color: tmpl.color,
                            }}
                          >
                            <HabitIcon name={tmpl.icon} className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                              {tmpl.name}
                              {tmpl.category === 'attendance' && (
                                <span className="text-[10px] bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 px-1.5 py-0.5 rounded-full font-medium">
                                  Attendance
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                              {tmpl.description}
                            </p>
                          </div>
                        </div>

                        <div className="shrink-0 ml-2">
                          {isAlreadyAdded ? (
                            <span className="text-xs text-zinc-400 font-medium">Added</span>
                          ) : (
                            <div className="w-7 h-7 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-600 dark:text-zinc-300">
                              <Plus className="w-4 h-4" />
                            </div>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <form onSubmit={handleCustomSubmit} className="space-y-4">
                {error && (
                  <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 text-xs">
                    {error}
                  </div>
                )}

                {/* Habit Name */}
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Activity Name
                  </label>
                  <input
                    type="text"
                    id="custom-habit-name-input"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      setError('');
                    }}
                    placeholder="e.g., Reading Book, Meditation, Math Practice"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Category
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {CATEGORIES.map((cat) => (
                      <button
                        type="button"
                        key={cat.id}
                        onClick={() => setCategory(cat.id)}
                        className={`text-xs py-2 px-2.5 rounded-xl border text-left font-medium transition-all ${
                          category === cat.id
                            ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 border-zinc-900 dark:border-zinc-100'
                            : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-50 dark:hover:bg-zinc-800'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Icon Selection */}
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Choose Icon
                  </label>
                  <div className="grid grid-cols-5 gap-2 max-h-32 overflow-y-auto p-1 border border-zinc-100 dark:border-zinc-800 rounded-xl">
                    {AVAILABLE_ICONS.map((ic) => (
                      <button
                        type="button"
                        key={ic.name}
                        onClick={() => setIcon(ic.name)}
                        className={`p-2 rounded-xl flex flex-col items-center justify-center gap-1 transition-all ${
                          icon === ic.name
                            ? 'bg-emerald-500/15 text-emerald-600 ring-2 ring-emerald-500/50'
                            : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                        }`}
                      >
                        <HabitIcon name={ic.name} className="w-5 h-5" />
                        <span className="text-[9px] truncate max-w-full">{ic.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Selection */}
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Color Accent
                  </label>
                  <div className="flex items-center gap-2">
                    {PRESET_COLORS.map((c) => (
                      <button
                        type="button"
                        key={c}
                        onClick={() => setColor(c)}
                        className="w-7 h-7 rounded-full flex items-center justify-center transition-transform hover:scale-110"
                        style={{ backgroundColor: c }}
                      >
                        {color === c && <Check className="w-4 h-4 text-white stroke-[3]" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Notes or Target Frequency */}
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Target Days Per Week
                  </label>
                  <div className="flex items-center gap-2">
                    {[3, 4, 5, 6, 7].map((days) => (
                      <button
                        key={days}
                        type="button"
                        onClick={() => setTargetDaysPerWeek(days)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                          targetDaysPerWeek === days
                            ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 border-zinc-900'
                            : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                        }`}
                      >
                        {days}d
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1.5">
                    Goal / Note (Optional)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g., 30 mins every morning, 8 glasses"
                    className="w-full px-3.5 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500/50"
                  />
                </div>

                <button
                  type="submit"
                  id="create-custom-habit-submit"
                  className="w-full py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 dark:bg-zinc-100 dark:hover:bg-white text-white dark:text-zinc-900 font-semibold text-sm transition-all shadow-sm cursor-pointer mt-2"
                >
                  Create Habit
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
