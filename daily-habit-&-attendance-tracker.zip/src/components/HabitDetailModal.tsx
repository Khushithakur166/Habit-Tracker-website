import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Flame, Award, Calendar, Check, Trash2, ArrowUpRight, TrendingUp } from 'lucide-react';
import { Habit } from '../types';
import { HabitIcon } from './HabitIcon';
import { addDays, formatDateLabel, getDayInitial, getDayNumber, getRecentDateStrings, getTodayDateString } from '../utils/dateUtils';

interface HabitDetailModalProps {
  habit: Habit | null;
  onClose: () => void;
  onToggleDateCheckin: (habitId: string, date: string) => void;
  onDeleteHabit: (habitId: string) => void;
}

export const HabitDetailModal: React.FC<HabitDetailModalProps> = ({
  habit,
  onClose,
  onToggleDateCheckin,
  onDeleteHabit,
}) => {
  if (!habit) return null;

  const today = getTodayDateString();
  const past30Days = getRecentDateStrings(28, today); // 4 full weeks of 7 days = 28 days

  // Compute 30-day attendance percentage
  const attendedIn30Days = past30Days.filter((d) => habit.history[d]).length;
  const attendanceRate = Math.round((attendedIn30Days / past30Days.length) * 100);

  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${habit.name}"? Progress will be permanently removed.`)) {
      onDeleteHabit(habit.id);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-t-3xl sm:rounded-3xl shadow-xl border border-zinc-200 dark:border-zinc-800 max-h-[92vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="p-5 flex items-start justify-between border-b border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center gap-3.5">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                style={{
                  backgroundColor: `${habit.color}20`,
                  color: habit.color,
                }}
              >
                <HabitIcon name={habit.icon} className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-100 leading-tight">
                  {habit.name}
                </h2>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs capitalize text-zinc-500 dark:text-zinc-400">
                    {habit.category}
                  </span>
                  {habit.notes && (
                    <>
                      <span className="text-zinc-300 dark:text-zinc-700">•</span>
                      <span className="text-xs text-zinc-500 dark:text-zinc-400 truncate max-w-[160px]">
                        {habit.notes}
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              id="close-habit-detail"
              className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stats Bar */}
          <div className="p-5 overflow-y-auto space-y-5">
            <div className="grid grid-cols-3 gap-2.5">
              <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200/60 dark:border-zinc-800 text-center">
                <div className="flex items-center justify-center text-amber-500 mb-1">
                  <Flame className="w-4 h-4 fill-amber-500" />
                </div>
                <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100">
                  {habit.streak}
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                  Current Streak
                </div>
              </div>

              <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200/60 dark:border-zinc-800 text-center">
                <div className="flex items-center justify-center text-emerald-500 mb-1">
                  <Award className="w-4 h-4" />
                </div>
                <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100">
                  {habit.bestStreak}
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                  Best Streak
                </div>
              </div>

              <div className="p-3 bg-zinc-50 dark:bg-zinc-800/60 rounded-2xl border border-zinc-200/60 dark:border-zinc-800 text-center">
                <div className="flex items-center justify-center text-indigo-500 mb-1">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div className="text-xl font-bold text-zinc-900 dark:text-zinc-100">
                  {attendanceRate}%
                </div>
                <div className="text-[11px] text-zinc-500 dark:text-zinc-400 font-medium">
                  Attendance
                </div>
              </div>
            </div>

            {/* Attendance Calendar Heatmap (Past 4 Weeks) */}
            <div className="bg-zinc-50 dark:bg-zinc-800/40 p-4 rounded-2xl border border-zinc-200/60 dark:border-zinc-800">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                  <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Past 4 Weeks Attendance Grid</span>
                </div>
                <span className="text-[11px] text-zinc-400">
                  Tap day to toggle
                </span>
              </div>

              {/* Grid of 28 days (4 weeks x 7 days) */}
              <div className="grid grid-cols-7 gap-1.5">
                {past30Days.map((d) => {
                  const isDone = !!habit.history[d];
                  const isCurrentDay = d === today;
                  const dayNum = getDayNumber(d);

                  return (
                    <button
                      key={d}
                      id={`calendar-day-${d}`}
                      onClick={() => onToggleDateCheckin(habit.id, d)}
                      title={`${formatDateLabel(d)}: ${isDone ? 'Attended' : 'Missed'}`}
                      className={`h-9 rounded-xl flex flex-col items-center justify-center relative transition-all cursor-pointer ${
                        isDone
                          ? 'bg-emerald-500 text-white font-bold shadow-xs'
                          : 'bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border border-zinc-200/60 dark:border-zinc-700/60 hover:bg-zinc-100 dark:hover:bg-zinc-700'
                      } ${isCurrentDay ? 'ring-2 ring-zinc-900 dark:ring-zinc-100 ring-offset-1' : ''}`}
                    >
                      <span className="text-[11px] leading-none">{dayNum}</span>
                      {isDone && <Check className="w-2.5 h-2.5 stroke-[3] mt-0.5" />}
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-[11px] text-zinc-500 dark:text-zinc-400 mt-3 pt-2 border-t border-zinc-200/50 dark:border-zinc-800">
                <span>{attendedIn30Days} of 28 days completed</span>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500" />
                    <span>Attended</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-xs bg-zinc-200 dark:bg-zinc-700" />
                    <span>Missed</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Attendance & Streak Guidance */}
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-800 dark:text-emerald-300">
              <span className="font-semibold block mb-0.5">Discipline & Attendance Tip:</span>
              Daily check-ins keep your streak glowing. If you attend or complete this activity for 7 continuous days, you unlock the consistency badge.
            </div>

            {/* Actions: Delete Habit */}
            <div className="pt-2 flex justify-between items-center">
              <button
                type="button"
                id="delete-habit-btn"
                onClick={handleDelete}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Activity</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2 text-xs font-semibold bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 rounded-xl hover:opacity-90 transition-opacity"
              >
                Done
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
