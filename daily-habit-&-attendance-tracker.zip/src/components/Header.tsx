import React from 'react';
import { Volume2, VolumeX, CheckCircle, Flame, Moon, Sun } from 'lucide-react';
import { formatDateLabel, getTodayDateString } from '../utils/dateUtils';
import { Habit } from '../types';

interface HeaderProps {
  selectedDate: string;
  habits: Habit[];
  soundEnabled: boolean;
  onToggleSound: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedDate,
  habits,
  soundEnabled,
  onToggleSound,
  isDarkMode,
  onToggleTheme,
}) => {
  const today = getTodayDateString();
  const isToday = selectedDate === today;

  // Completed count on selected date
  const completedCount = habits.filter((h) => h.history[selectedDate]).length;
  const totalCount = habits.length;

  const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <header className="pt-6 pb-3 px-1">
      <div className="flex items-center justify-between mb-2">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 tracking-wide uppercase">
              {isToday ? 'Today' : 'Date Selected'}
            </span>
            {isToday && (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight">
            {formatDateLabel(selectedDate)}
          </h1>
        </div>

        {/* Quick controls */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            id="toggle-sound-btn"
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute micro-sounds' : 'Enable check-in chimes'}
            className="w-9 h-9 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/80 flex items-center justify-center text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors shadow-xs cursor-pointer"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-zinc-400" />
            )}
          </button>

          <button
            type="button"
            id="toggle-theme-btn"
            onClick={onToggleTheme}
            title="Toggle theme"
            className="w-9 h-9 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/80 flex items-center justify-center text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 transition-colors shadow-xs cursor-pointer"
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-zinc-600" />
            )}
          </button>
        </div>
      </div>

      {/* Daily Progress summary line and animated bar */}
      <div className="pt-1.5 space-y-1.5">
        <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
          <span>
            <strong className="text-zinc-800 dark:text-zinc-200 font-semibold">{completedCount}</strong> of{' '}
            {totalCount} habits checked in
          </span>

          {completedCount === totalCount && totalCount > 0 ? (
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold animate-pulse">
              <CheckCircle className="w-3.5 h-3.5" />
              All done for today!
            </span>
          ) : (
            <span className="text-zinc-400 font-medium">
              {percent}% completed
            </span>
          )}
        </div>

        {/* Animated Progress Bar */}
        <div className="w-full h-1.5 bg-zinc-200/80 dark:bg-zinc-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-400 transition-all duration-500 ease-out rounded-full"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>
    </header>
  );
};
