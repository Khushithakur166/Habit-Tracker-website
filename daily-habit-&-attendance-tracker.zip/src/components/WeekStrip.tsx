import React from 'react';
import { motion } from 'motion/react';
import { getDayInitial, getDayNumber, getTodayDateString, getWeekDays } from '../utils/dateUtils';
import { Habit } from '../types';

interface WeekStripProps {
  selectedDate: string;
  onSelectDate: (date: string) => void;
  habits: Habit[];
}

export const WeekStrip: React.FC<WeekStripProps> = ({ selectedDate, onSelectDate, habits }) => {
  const today = getTodayDateString();
  const weekDays = getWeekDays(today);

  return (
    <div className="w-full bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xs rounded-2xl p-3 border border-emerald-100/60 dark:border-zinc-800 shadow-xs">
      <div className="flex items-center justify-between gap-1">
        {weekDays.map((dayStr) => {
          const isSelected = dayStr === selectedDate;
          const isToday = dayStr === today;
          const dayName = getDayInitial(dayStr);
          const dayNum = getDayNumber(dayStr);

          // Count completed habits on this date
          const completedCount = habits.filter((h) => h.history[dayStr]).length;
          const totalHabits = habits.length;
          const isAllDone = totalHabits > 0 && completedCount === totalHabits;
          const hasAnyDone = completedCount > 0;

          return (
            <motion.button
              whileTap={{ scale: 0.94 }}
              key={dayStr}
              id={`week-day-${dayStr}`}
              onClick={() => onSelectDate(dayStr)}
              className={`flex-1 flex flex-col items-center py-2 px-1 rounded-xl transition-all relative group cursor-pointer ${
                isSelected
                  ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 shadow-sm font-semibold'
                  : 'hover:bg-emerald-50/50 dark:hover:bg-zinc-800/60 text-zinc-600 dark:text-zinc-400'
              }`}
            >
              {isToday && !isSelected && (
                <span className="absolute -top-1 w-1.5 h-1.5 bg-emerald-500 rounded-full" />
              )}

              <span className={`text-[11px] font-medium tracking-tight ${isSelected ? 'opacity-90' : 'text-zinc-400 dark:text-zinc-500'}`}>
                {dayName}
              </span>
              <span className="text-sm font-semibold mt-0.5">{dayNum}</span>

              {/* Attendance Mini Indicator */}
              <div className="mt-1 flex items-center justify-center h-2">
                {isAllDone ? (
                  <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-emerald-400' : 'bg-emerald-500'}`} />
                ) : hasAnyDone ? (
                  <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-amber-300' : 'bg-amber-500/80'}`} />
                ) : (
                  <span className="w-1 h-1 rounded-full bg-zinc-200 dark:bg-zinc-700" />
                )}
              </div>
            </motion.button>
          );
        })}
      </div>

      <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400 mt-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800/80 px-1">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
          All Done
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
          Partial
        </span>
        <button
          onClick={() => onSelectDate(today)}
          className={`font-medium transition-colors hover:text-emerald-600 ${
            selectedDate === today ? 'text-emerald-600 dark:text-emerald-400 font-semibold' : ''
          }`}
        >
          {selectedDate === today ? '● Today' : 'Jump to Today'}
        </button>
      </div>
    </div>
  );
};
