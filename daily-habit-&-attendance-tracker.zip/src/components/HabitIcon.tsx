import React from 'react';
import {
  Droplets,
  Waves,
  Dumbbell,
  Sparkles,
  BookOpen,
  GraduationCap,
  Flame,
  Heart,
  Coffee,
  Sun,
  Bike,
  Clock,
  CheckCircle2,
  Apple,
  Bed,
  Smile,
  Compass,
  Zap,
  Target,
  LucideIcon,
} from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  Droplets,
  Waves,
  Dumbbell,
  Sparkles,
  BookOpen,
  GraduationCap,
  Flame,
  Heart,
  Coffee,
  Sun,
  Bike,
  Clock,
  CheckCircle2,
  Apple,
  Bed,
  Smile,
  Compass,
  Zap,
  Target,
};

interface HabitIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const HabitIcon: React.FC<HabitIconProps> = ({ name, className = 'w-5 h-5', size }) => {
  const IconComponent = ICON_MAP[name] || CheckCircle2;
  return <IconComponent className={className} size={size} />;
};

export const AVAILABLE_ICONS = [
  { name: 'Droplets', label: 'Hydration' },
  { name: 'Waves', label: 'Swimming' },
  { name: 'Dumbbell', label: 'Workout' },
  { name: 'Sparkles', label: 'Skincare' },
  { name: 'BookOpen', label: 'Study' },
  { name: 'GraduationCap', label: 'College' },
  { name: 'Flame', label: 'Discipline' },
  { name: 'Heart', label: 'Health' },
  { name: 'Sun', label: 'Morning' },
  { name: 'Coffee', label: 'Routine' },
  { name: 'Bike', label: 'Cycling' },
  { name: 'Apple', label: 'Nutrition' },
  { name: 'Bed', label: 'Sleep' },
  { name: 'Zap', label: 'Energy' },
  { name: 'Target', label: 'Goal' },
];
