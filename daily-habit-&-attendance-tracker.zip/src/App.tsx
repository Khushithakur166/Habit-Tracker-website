import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle2,
  CalendarCheck,
  ListTodo,
  BarChart3,
  Plus,
  Sparkles,
  Flame,
  Filter,
} from 'lucide-react';
import confetti from 'canvas-confetti';

import { ActiveTab, Habit, HabitCategory, TodoItem } from './types';
import {
  calculateStreaks,
  getTodayDateString,
} from './utils/dateUtils';
import {
  loadHabits,
  saveHabits,
  loadTodos,
  saveTodos,
  loadSettings,
  saveSettings,
  getDefaultHabits,
  getDefaultTodos,
} from './utils/storage';
import { playCelebrationSound, playCheckmarkSound, playPopSound } from './utils/sound';

import { Header } from './components/Header';
import { WeekStrip } from './components/WeekStrip';
import { HabitCard } from './components/HabitCard';
import { AddHabitModal } from './components/AddHabitModal';
import { HabitDetailModal } from './components/HabitDetailModal';
import { TodoList } from './components/TodoList';
import { StatsView } from './components/StatsView';

export default function App() {
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());
  const [activeTab, setActiveTab] = useState<ActiveTab>('habits');
  const [habits, setHabits] = useState<Habit[]>(() => loadHabits());
  const [todos, setTodos] = useState<TodoItem[]>(() => loadTodos());
  const [settings, setSettings] = useState(() => loadSettings());

  // Dark mode state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem('theme_mode') === 'dark' ||
        window.matchMedia('(prefers-color-scheme: dark)').matches
      );
    }
    return false;
  });

  // Modal states
  const [isAddHabitOpen, setIsAddHabitOpen] = useState(false);
  const [selectedHabitDetail, setSelectedHabitDetail] = useState<Habit | null>(null);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Sync dark mode class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme_mode', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme_mode', 'light');
    }
  }, [isDarkMode]);

  // Persist habits on changes
  useEffect(() => {
    saveHabits(habits);
  }, [habits]);

  // Persist todos on changes
  useEffect(() => {
    saveTodos(todos);
  }, [todos]);

  // Persist settings
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  const handleToggleSound = () => {
    setSettings((prev) => ({
      ...prev,
      soundEnabled: !prev.soundEnabled,
    }));
  };

  const handleToggleTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Toggle habit check-in for a given date
  const handleToggleCheckin = (habitId: string, date: string) => {
    const today = getTodayDateString();
    let willBeCompleted = false;

    setHabits((prevHabits) => {
      const updated = prevHabits.map((h) => {
        if (h.id !== habitId) return h;

        const newHistory = { ...h.history };
        if (newHistory[date]) {
          delete newHistory[date];
          willBeCompleted = false;
        } else {
          newHistory[date] = true;
          willBeCompleted = true;
        }

        const { currentStreak, bestStreak } = calculateStreaks(newHistory, today);

        return {
          ...h,
          history: newHistory,
          streak: currentStreak,
          bestStreak: Math.max(bestStreak, h.bestStreak),
        };
      });

      // Sound feedback
      if (willBeCompleted) {
        playCheckmarkSound(settings.soundEnabled);

        // Check if all habits on this date are now completed
        const allCompletedNow = updated.every((item) => item.history[date]);
        if (allCompletedNow && updated.length > 0) {
          playCelebrationSound(settings.soundEnabled);
          confetti({
            particleCount: 45,
            spread: 60,
            origin: { y: 0.65 },
            colors: ['#10b981', '#06b6d4', '#8b5cf6', '#f59e0b', '#f43f5e'],
          });
        }
      } else {
        playPopSound(settings.soundEnabled);
      }

      return updated;
    });

    // Also update selectedHabitDetail if currently open in modal
    if (selectedHabitDetail && selectedHabitDetail.id === habitId) {
      setSelectedHabitDetail((prev) => {
        if (!prev) return null;
        const newHistory = { ...prev.history };
        if (newHistory[date]) {
          delete newHistory[date];
        } else {
          newHistory[date] = true;
        }
        const { currentStreak, bestStreak } = calculateStreaks(newHistory, today);
        return {
          ...prev,
          history: newHistory,
          streak: currentStreak,
          bestStreak: Math.max(bestStreak, prev.bestStreak),
        };
      });
    }
  };

  // Add new habit
  const handleAddHabit = (newHabitData: Omit<Habit, 'id' | 'createdAt' | 'history' | 'streak' | 'bestStreak'>) => {
    const today = getTodayDateString();
    const newHabit: Habit = {
      ...newHabitData,
      id: `habit-${Date.now()}`,
      createdAt: today,
      history: {},
      streak: 0,
      bestStreak: 0,
    };

    setHabits((prev) => [newHabit, ...prev]);
    playPopSound(settings.soundEnabled);
  };

  // Delete habit
  const handleDeleteHabit = (habitId: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== habitId));
    playPopSound(settings.soundEnabled);
  };

  // Add Todo item
  const handleAddTodo = (newTodoData: Omit<TodoItem, 'id' | 'createdAt'>) => {
    const today = getTodayDateString();
    const newTodo: TodoItem = {
      ...newTodoData,
      id: `todo-${Date.now()}`,
      createdAt: today,
    };
    setTodos((prev) => [newTodo, ...prev]);
    playPopSound(settings.soundEnabled);
  };

  // Toggle Todo completion
  const handleToggleTodo = (id: string) => {
    setTodos((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const willComplete = !t.completed;
        if (willComplete) {
          playCheckmarkSound(settings.soundEnabled);
        } else {
          playPopSound(settings.soundEnabled);
        }
        return {
          ...t,
          completed: willComplete,
          completedAt: willComplete ? getTodayDateString() : undefined,
        };
      })
    );
  };

  // Delete Todo
  const handleDeleteTodo = (id: string) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  };

  // Clear completed Todos
  const handleClearCompletedTodos = () => {
    setTodos((prev) => prev.filter((t) => !t.completed));
  };

  // Reset to default activities
  const handleResetToDefaults = () => {
    const defaults = getDefaultHabits();
    const defaultTodos = getDefaultTodos();
    setHabits(defaults);
    setTodos(defaultTodos);
    saveHabits(defaults);
    saveTodos(defaultTodos);
  };

  // Filtered habits
  const filteredHabits = habits.filter((h) => {
    if (selectedCategoryFilter === 'all') return true;
    if (selectedCategoryFilter === 'attendance') return h.category === 'attendance';
    if (selectedCategoryFilter === 'health') return h.category === 'health' || h.category === 'fitness';
    if (selectedCategoryFilter === 'education') return h.category === 'education';
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50/60 via-teal-50/40 to-sky-50/60 dark:from-zinc-950 dark:via-zinc-900 dark:to-zinc-950 flex justify-center selection:bg-emerald-500/20 selection:text-emerald-700 relative overflow-x-hidden">
      {/* Subtle animated ambient light gradient blobs for atmospheric depth */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-emerald-200/40 dark:bg-emerald-950/20 blur-3xl animate-float-slow" />
        <div className="absolute top-1/3 -right-32 w-80 h-80 rounded-full bg-teal-200/35 dark:bg-teal-950/20 blur-3xl animate-float-reverse" />
        <div className="absolute -bottom-24 left-1/4 w-88 h-88 rounded-full bg-sky-200/35 dark:bg-sky-950/20 blur-3xl animate-pulse-glow" />
      </div>

      {/* Mobile-sized canvas / centered viewport */}
      <div className="w-full max-w-md min-h-screen bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md border-x border-emerald-100/80 dark:border-zinc-800/80 flex flex-col pb-24 shadow-2xl relative z-10">
        {/* Top Header */}
        <div className="px-4">
          <Header
            selectedDate={selectedDate}
            habits={habits}
            soundEnabled={settings.soundEnabled}
            onToggleSound={handleToggleSound}
            isDarkMode={isDarkMode}
            onToggleTheme={handleToggleTheme}
          />

          {/* Week Strip for Day-by-Day Tracking */}
          <div className="mt-2 mb-4">
            <WeekStrip
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              habits={habits}
            />
          </div>
        </div>

        {/* Tab Navigation Segment */}
        <div className="px-4 mb-3">
          <div className="grid grid-cols-3 p-1 bg-zinc-200/70 dark:bg-zinc-800/80 rounded-2xl text-xs font-semibold">
            <button
              id="tab-btn-habits"
              onClick={() => setActiveTab('habits')}
              className={`py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'habits'
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100'
              }`}
            >
              <CalendarCheck className="w-3.5 h-3.5" />
              <span>Habits</span>
            </button>

            <button
              id="tab-btn-todos"
              onClick={() => setActiveTab('todos')}
              className={`py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'todos'
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100'
              }`}
            >
              <ListTodo className="w-3.5 h-3.5" />
              <span>To-Dos</span>
              {todos.filter((t) => !t.completed).length > 0 && (
                <span className="w-4 h-4 rounded-full bg-emerald-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {todos.filter((t) => !t.completed).length}
                </span>
              )}
            </button>

            <button
              id="tab-btn-stats"
              onClick={() => setActiveTab('stats')}
              className={`py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'stats'
                  ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white shadow-xs'
                  : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Stats</span>
            </button>
          </div>
        </div>

        {/* Content Body Based on Tab */}
        <main className="px-4 flex-1">
          <AnimatePresence mode="wait">
            {activeTab === 'habits' && (
              <motion.div
                key="tab-habits"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18, ease: 'easeOut' }}
                className="space-y-3"
              >
                {/* Category Quick Filter Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                  {[
                    { id: 'all', label: 'All Habits' },
                    { id: 'attendance', label: 'College Attendance' },
                    { id: 'health', label: 'Health & Workout' },
                    { id: 'education', label: 'Study' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      id={`filter-${f.id}`}
                      onClick={() => setSelectedCategoryFilter(f.id)}
                      className={`px-3 py-1.5 rounded-xl shrink-0 font-medium transition-all cursor-pointer ${
                        selectedCategoryFilter === f.id
                          ? 'bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 font-semibold shadow-2xs'
                          : 'bg-white/90 dark:bg-zinc-850 text-zinc-600 dark:text-zinc-400 border border-zinc-200/70 dark:border-zinc-800 hover:bg-emerald-50/50 dark:hover:bg-zinc-800'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                {/* Habit Cards List */}
                <div className="space-y-2.5">
                  <AnimatePresence mode="popLayout">
                    {filteredHabits.length === 0 ? (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="py-12 text-center bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/60 dark:border-zinc-800 p-6"
                      >
                        <Sparkles className="w-8 h-8 text-zinc-400 mx-auto mb-2" />
                        <p className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
                          No habits in this category
                        </p>
                        <button
                          onClick={() => setIsAddHabitOpen(true)}
                          className="mt-3 px-4 py-2 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 text-xs font-semibold inline-flex items-center gap-1.5"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add Habit</span>
                        </button>
                      </motion.div>
                    ) : (
                      filteredHabits.map((habit) => (
                        <HabitCard
                          key={habit.id}
                          habit={habit}
                          selectedDate={selectedDate}
                          onToggleCheckin={handleToggleCheckin}
                          onOpenDetail={setSelectedHabitDetail}
                        />
                      ))
                    )}
                  </AnimatePresence>
                </div>

                {/* Quick Add Habit Button at bottom of list */}
                <button
                  type="button"
                  id="add-habit-inline-btn"
                  onClick={() => setIsAddHabitOpen(true)}
                  className="w-full py-3.5 rounded-2xl border-2 border-dashed border-emerald-200/80 dark:border-zinc-800 hover:border-emerald-300 dark:hover:border-zinc-700 text-zinc-500 dark:text-zinc-400 font-semibold text-xs flex items-center justify-center gap-2 hover:bg-emerald-50/40 dark:hover:bg-zinc-850/60 transition-all cursor-pointer shadow-2xs mt-2"
                >
                  <Plus className="w-4 h-4 text-emerald-500" />
                  <span>Add Activity or Attendance Habit</span>
                </button>
              </motion.div>
            )}

            {activeTab === 'todos' && (
              <motion.div
                key="tab-todos"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18, ease: 'easeOut' }}
              >
                <TodoList
                  todos={todos}
                  selectedDate={selectedDate}
                  onToggleTodo={handleToggleTodo}
                  onAddTodo={handleAddTodo}
                  onDeleteTodo={handleDeleteTodo}
                  onClearCompleted={handleClearCompletedTodos}
                />
              </motion.div>
            )}

            {activeTab === 'stats' && (
              <motion.div
                key="tab-stats"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18, ease: 'easeOut' }}
              >
                <StatsView
                  habits={habits}
                  onResetToDefaults={handleResetToDefaults}
                  onOpenHabitDetail={setSelectedHabitDetail}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Bottom Floating Action Button (for habits tab) */}
        {activeTab === 'habits' && (
          <div className="fixed bottom-6 right-6 sm:static sm:mt-4 sm:flex sm:justify-center sm:pointer-events-none z-30">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsAddHabitOpen(true)}
              id="fab-add-habit"
              className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 cursor-pointer sm:pointer-events-auto sm:hidden"
              aria-label="Add habit"
            >
              <Plus className="w-7 h-7 stroke-[2.5]" />
            </motion.button>
          </div>
        )}

        {/* Modals */}
        <AddHabitModal
          isOpen={isAddHabitOpen}
          onClose={() => setIsAddHabitOpen(false)}
          onAddHabit={handleAddHabit}
          existingHabitNames={habits.map((h) => h.name)}
        />

        <HabitDetailModal
          habit={selectedHabitDetail}
          onClose={() => setSelectedHabitDetail(null)}
          onToggleDateCheckin={handleToggleCheckin}
          onDeleteHabit={handleDeleteHabit}
        />
      </div>
    </div>
  );
}
